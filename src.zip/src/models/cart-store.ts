export class CartStore {
  id?: string;
  name: string;
  subTotal?: number;
  items?: Array<any>;

  constructor() {
  }
}
