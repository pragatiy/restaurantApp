var Variation = /** @class */ (function () {
    function Variation() {
    }
    return Variation;
}());
export { Variation };
//# sourceMappingURL=variation.js.map