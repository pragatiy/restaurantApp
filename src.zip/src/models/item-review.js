var ItemReview = /** @class */ (function () {
    function ItemReview() {
    }
    return ItemReview;
}());
export { ItemReview };
//# sourceMappingURL=item-review.js.map