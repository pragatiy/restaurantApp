var Store = /** @class */ (function () {
    function Store() {
    }
    return Store;
}());
export { Store };
//# sourceMappingURL=store.js.map