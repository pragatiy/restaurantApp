var Item = /** @class */ (function () {
    function Item() {
    }
    return Item;
}());
export { Item };
//# sourceMappingURL=item.js.map