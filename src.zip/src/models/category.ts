export class Category {
  id?: string;
  name: string;
  parentId?: string;
  thumbnail?: string;
  itemCount?: number;

  constructor() {
  }
}
