export class Store {
  id?: string;
  name: string;
  address: string;
  itemCount?: number;
  rateCount?: number;
  rating?: number;

  constructor() {
  }
}
