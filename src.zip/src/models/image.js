var Image = /** @class */ (function () {
    function Image() {
    }
    return Image;
}());
export { Image };
//# sourceMappingURL=image.js.map