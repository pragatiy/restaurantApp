export class Variation {
  id?: string;
  name: string;
  price: number;
  checked?: boolean;

  constructor() {
  }
}
