var OrderNotification = /** @class */ (function () {
    function OrderNotification() {
    }
    return OrderNotification;
}());
export { OrderNotification };
//# sourceMappingURL=order-notification.js.map