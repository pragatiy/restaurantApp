var CartItem = /** @class */ (function () {
    function CartItem() {
    }
    return CartItem;
}());
export { CartItem };
//# sourceMappingURL=cart-item.js.map