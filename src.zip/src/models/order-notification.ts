export class OrderNotification {
  orderId: string;
  storeId?: string;
  userId?: string;

  constructor() {
  }
}
