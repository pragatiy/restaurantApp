export class Tax {
  name: string;
  enable: boolean;
  rate: number;

  constructor() {
  }
}
