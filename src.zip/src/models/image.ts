export class Image {
  thumbnail: string;
  src: string;

  constructor() {
  }
}
