var Order = /** @class */ (function () {
    function Order() {
    }
    return Order;
}());
export { Order };
//# sourceMappingURL=order.js.map