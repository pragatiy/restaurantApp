import { User } from "./user";

export class ItemReview {
  user?: User;
  comment: string;
  rating: number;

  constructor() {
  }
}
