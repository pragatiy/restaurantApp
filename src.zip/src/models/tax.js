var Tax = /** @class */ (function () {
    function Tax() {
    }
    return Tax;
}());
export { Tax };
//# sourceMappingURL=tax.js.map