var Size = /** @class */ (function () {
    function Size() {
    }
    return Size;
}());
export { Size };
//# sourceMappingURL=size.js.map