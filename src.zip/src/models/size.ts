export class Size {
  id?: string;
  name: string;
  price: number;

  constructor() {
  }
}
