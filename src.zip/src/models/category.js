var Category = /** @class */ (function () {
    function Category() {
    }
    return Category;
}());
export { Category };
//# sourceMappingURL=category.js.map