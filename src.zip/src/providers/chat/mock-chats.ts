export let CHATS = [
  {
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'assets/img/ben.png',
    messages: [
      {
        type: 'received',
        text: 'Hey, How are you? wanna hang out this friday?',
        image: '',
        time: 'Thursday 05:55 PM'
      },
      {
        type: 'sent',
        text: 'Good, Yes sure why not :D',
        image: '',
        time: 'Thursday 05:56 PM'
      },
      {
        type: 'received',
        text: 'Check out this view from my last trip',
        image: '',
        time: 'Thursday 05:57 PM'
      },
      {
        type: 'sent',
        text: 'Looks Great is that view in Canada?',
        image: '',
        time: 'Thursday 05:58 PM'
      },
      {
        type: 'received',
        text: 'Yes, it\'s in Canada',
        image: '',
        time: 'Thursday 05:57 PM'
      }
    ]
  },
  {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'assets/img/max.png'
  },
  {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'assets/img/adam.jpg'
  },
  {

    d: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'assets/img/perry.png'
  },
  {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'assets/img/mike.png'
  },
  {
    id: 5,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'assets/img/ben.png'
  },
  {
    id: 6,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'assets/img/max.png'
  }
];
