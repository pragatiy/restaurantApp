export var DEFAULT_AVATAR = 'https://i.imgur.com/NvB4Mhc.png';
export var DEFAULT_CAT_THUMB = 'assets/imgs/default-thumbnail.jpg';
export var DEFAULT_ITEM_THUMB = 'assets/imgs/default-thumbnail.jpg';
//# sourceMappingURL=constants.js.map