export let DEFAULT_AVATAR = 'https://i.imgur.com/NvB4Mhc.png';
export let DEFAULT_CAT_THUMB = 'assets/imgs/default-thumbnail.jpg';
export let DEFAULT_ITEM_THUMB = 'assets/imgs/default-thumbnail.jpg';
