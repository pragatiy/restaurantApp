export var POSTS = [
    {
        id: 1,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/brick_chicken.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 2,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/fried_calamari.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 3,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/marsala_chicken.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 4,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/rib_eyes.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 5,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/seared_tuna.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 6,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/zuppa.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    },
    {
        id: 7,
        title: 'Lorem Ipsum is simply',
        thumb: 'assets/img/items/thumbs/brick_chicken.jpg',
        desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever si"
    }
];
//# sourceMappingURL=mock-posts.js.map