import { Component } from '@angular/core';
import { NavController, AlertController, NavParams } from 'ionic-angular';
import { HomePage } from "../home/home";
import { Cart } from "../../models/cart";
import { OrderProvider } from "../../providers/order/order";

/*
 Generated class for the LoginPage page.

 See http://ionicframework.com/docs/v2/components/#navigation for more info on
 Ionic pages and navigation.
 */
@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html'
})
export class CheckoutPage {
  cart: Cart;
  isEditing = false;
  address: any;

  constructor(public nav: NavController, public alertController: AlertController, public navParasm: NavParams,
              public orderProvider: OrderProvider) {
    this.address = localStorage.getItem('deliveryAddress');
    if (this.address) {
      // code...
    }else{
      this.address = "3119 S Semoran Blvd, Orlando, FL 32822, USA"
    }
    this.cart = navParasm.get('cart');
  }

  // edit address
  editAddress() {
    let prompt = this.alertController.create({
      title: 'Address',
      message: "",
      inputs: [
        {
          name: 'address',
          value: ''
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            console.log('Saved clicked');
          }
        }
      ]
    });

    prompt.present();
  }

  // place order button click
  buy() {
    // need to validate the address
    if (!this.address || (this.address.length < 10)) {
      // show alert
      let alert = this.alertController.create({
        title: 'Info',
        subTitle: 'Please enter valid address',
        buttons: ['OK']
      });
      alert.present();
      return false;
    }

debugger;
    this.orderProvider.add(this.cart.stores, this.address);
    // show alert
    let alert = this.alertController.create({
      title: 'Info',
      subTitle: 'You can pick up by the change schedule / edit store',
      buttons: [
        {
          text: 'OK',
          handler: data => {
            // clear cart
            // this.cartService.clearCart();
            // back to home page
            this.nav.setRoot(HomePage);
          }
        }
      ]
    });

    alert.present();
  }

  // enable editing info
  enableEditing() {
    this.isEditing = true;
  }
}
