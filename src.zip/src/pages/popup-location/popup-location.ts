    import { Component,OnInit ,ViewChild, ElementRef, NgZone} from '@angular/core';
    import { IonicPage, NavController, NavParams, ViewController,AlertController } from 'ionic-angular';
    import { MapsAPILoader } from '@agm/core';
    import {} from 'googlemaps';
    import { FormControl } from '@angular/forms';
    import { HomePage } from '../home/home';
    import { StoreProvider } from "../../providers/store/store";
    import { Geolocation } from '@ionic-native/geolocation/ngx';
   // import { NativeGeocoder, NativeGeocoderReverseResult } from '@ionic-native/native-geocoder';
   // import { LocationAccuracy } from '@ionic-native/location-accuracy';



    /**
    * Generated class for the PopupLocationPage page.
    *
    * See https://ionicframework.com/docs/components/#navigation for more info on
    * Ionic pages and navigation.
    */

    @IonicPage()
    @Component({
    selector: 'page-popup-location',
    templateUrl: 'popup-location.html',
    queries: {
    nav: new ViewChild('content')
    }
    })
    export class PopupLocationPage {
    @ViewChild('search') public searchElement: ElementRef;
    public searchControl: FormControl;
    userLat:any;
    userLong:any;
    restauLat:any;
    restauLong:any;
    nav: any;
    stores:any;
    searchAddress:any;
    flag =1;
    constructor(public navCtrl: NavController,private geoLocation: Geolocation,private alertCtrl: AlertController,public storeProvider: StoreProvider,public viewCtrl : ViewController,private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public navParams: NavParams) {
        this.DisplayLocation();

    }


DisplayLocation(){
   this.ngZone.run(() => {
    this.storeProvider.all().subscribe(snapshot => {
        console.log("store data ",snapshot);
        if (snapshot) {
            this.stores = snapshot;   
        }else {
       console.log('No results found');
     }
      

    let restauLat;
    let restauLong;

      this.mapsAPILoader.load().then(() => {      
          //get the lat and long from address
       let geocoder = new google.maps.Geocoder; 
              let that = this;              
              let address =this.stores[0].address;
              console.log("address", address );
              geocoder.geocode({'address': address},(results) => {
                   console.log(results[0]);
                  if (results[0]) {
                     restauLat = results[0].geometry.location.lat();
                     restauLong =  results[0].geometry.location.lng();
                            console.log("restauLat", restauLat);
                            console.log("restauLong",restauLong);
                  } else {
                    console.log('No results found');
                  }
              });


    // get the lat and long from selected address
      let autocomplete = new google.maps.places.Autocomplete(this.searchElement.nativeElement, {
        types: ["address"]
      });
       console.log("autocomplete",autocomplete);
      autocomplete.addListener("place_changed", () => {
        
          //get the place result        
           let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          let arra:any= autocomplete.getPlace();
          this.searchAddress = place.formatted_address;
          localStorage.setItem('deliveryAddress', this.searchAddress);
             console.log("place",place);          
           /*   if(arra.length){              
                let lat = place[0].geometry.location.lat();
                let lng =  place[0].geometry.location.lng();
                console.log("lat",lat);
                console.log("lng",lng);
                      this.distance(lat, lng, restauLat, restauLong, "M")
                }
              else*/ 
              if(place.geometry){                   
                    this.distance( place.geometry.location.lat(), place.geometry.location.lng(), restauLat, restauLong, "M", 1)
                }else{
                    let alert = this.alertCtrl.create({
                          title: "",
                          subTitle: "Please re-enter the location!",
                          buttons: ["OK"]
                        });
                        alert.present();
                       
                }
            
                      //verify result
                      if (place.geometry === undefined || place.geometry === null) {
                        return;
                      }

                     });
          });
       }); 
    });

    }


currentLocation(){
    
    let restauLat;
    let restauLong;
    console.log("called current loc");
     this.mapsAPILoader.load().then(() => {      
    	//get the lat and long from address
       let geocoder = new google.maps.Geocoder; 
    		  let that = this;
    		  debugger;
    		  let address =this.stores[0].address;
    		  console.log("address current loc", address );
    		  geocoder.geocode({'address': address}, (results)=> {
    		  	 console.log(results[0]);                    
    		      if (results[0]) {
    		         this.restauLat = results[0].geometry.location.lat();
    			     this.restauLong =  results[0].geometry.location.lng();
    						console.log("restauLat", this.restauLat);
    						console.log("restauLong",this.restauLong);
    		      } else {
    		        console.log('No results found');
    		      }
    		  });

    let options = {
    		timeout: 30000,
    		enableHighAccuracy: true
    	}
                    
              	let watch = this.geoLocation.watchPosition();
             	watch.subscribe((data) => {   
                 this.flag++;  
                    // this.searchAddress = 
                    // localStorage.setItem('deliveryAddress', this.searchAddress);          
    			console.log('watchposition',data.coords.latitude,data.coords.longitude);					
    			this.distance(data.coords.latitude, data.coords.longitude, this.restauLat, this.restauLong, "M", this.flag)		 
    	  
            });
         

    });
    }





    ionViewDidLoad() {
    console.log('ionViewDidLoad PopupLocationPage');
    }

    distance(lat1, lon1, lat2, lon2, unit, flag) {
    //	debugger;
    if ((lat1 == lat2) && (lon1 == lon2)) {
    	return 0;
    }
    else {
    	var radlat1 = Math.PI * lat1/180;
    	var radlat2 = Math.PI * lat2/180;
    	var theta = lon1-lon2;
    	var radtheta = Math.PI * theta/180;
    	var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    	if (dist > 1) {
    		dist = 1;
    	}
    	dist = Math.acos(dist);
    	dist = dist * 180/Math.PI;
    	dist = dist * 60 * 1.1515;
    	if (unit=="K") { dist = dist * 1.609344 }
    	if (unit=="N") { dist = dist * 0.8684 }
    			console.log("dist",dist);
    	//return dist;
    	  if (dist >= 6) {
                     if (flag >2) {
                         // code...
                     }else{
                	    	let alert = this.alertCtrl.create({
                		              title: "",
                		              subTitle: "Please enter the location within six miles",
                		              buttons: ["OK"]
                		    });
                		       alert.present();
                       }

    	  }
          else{
              
    	  	
                  this.navCtrl.setRoot(HomePage,{'orderType':'Delivery','orderDetail':this.searchAddress});
    	  }

    }


    }


    dismiss(){
    	this.viewCtrl.dismiss();
    	}
    }
