import { Component, OnInit, } from '@angular/core';
import { Platform, AlertController } from 'ionic-angular';
import { ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams,  } from 'ionic-angular';
import { ViewController } from 'ionic-angular';

import { ModalController, ModalOptions } from "ionic-angular";
import { LoginPage } from '../login/login';
import { HomePage } from '../home/home';
import { DatePipe } from '@angular/common';

@IonicPage()
@Component({
  selector: 'page-popup',
  templateUrl: 'popup.html',
  queries: {
    nav: new ViewChild('content')
  },
  providers:[DatePipe]
})
export class PopupPage {

public now: string = new Date().toString();
email:any;
password:any;
minDate:string;
myTime:any;
nav:any;
currentDate:string;
  constructor(public navCtrl: NavController,private datePipe: DatePipe,public modalCtrl: ModalController,public viewCtrl : ViewController,public navParams: NavParams,private alertCtrl: AlertController) {
       
        this.minDate = this.datePipe.transform(this.now, 'yyyy-MM-dd');    
        this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');;
    
            this.myTime= this.datePipe.transform(new Date().toISOString(), 'HH-mm');
           
          //  let tzoffset = (new Date()).getTimezoneOffset() * 60000; //offset in milliseconds
           // this.myTime = (new Date(this.myStartTime - tzoffset)).toISOString().slice(0,-1);
                      // alert(this.myTime);
   }


         
timeSelect(){

//alert(this.myTime);

}

dateSelect(){

//alert(this.myDate);

}


 pickUpClick() {
  this.navCtrl.setRoot(HomePage,{'orderType':'PickUp'});   
 }

 deliveryClick(){  
   const modalOptions: ModalOptions = {
        cssClass: "signInModal"
      };
      const modal = this.modalCtrl.create("PopupLocationPage", {}, modalOptions);
      modal.present();  
  }

  upateClick(){

  }

  showAlert(err) {
    let alert = this.alertCtrl.create({
      title: "Error!",
      subTitle: err,
      buttons: ["OK"]
    });
    alert.present();
  }

  dismiss(){
  this.viewCtrl.dismiss();
  }

}
